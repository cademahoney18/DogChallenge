﻿using System;

namespace DogProgram
{
    public class Dog
    {
        public enum gender {
            MALE, FEMALE
        }
        String name;
        String owner;
        int age;

        public Dog(string dogName, string dogOwner, int dogAge){
            name = dogName;
            owner = dogOwner;
            age = dogAge;
        }

    }
}
